/**
 * 
 */
/**
 * @author indu-pt7191
 *
 */
module jdbcquery {
	requires java.sql;
}