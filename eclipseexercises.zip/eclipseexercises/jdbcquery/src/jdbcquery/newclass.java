package jdbcquery;
import java.sql.*;
public class newclass {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		
		String url="jdbc:mysql://localhost:3306/project",uname="root",pass="";
		String query="SELECT * FROM studentmaster ORDER BY std_name";
		String query2="select std_id,std_name,course_id,std_gender from studentmaster order by std_dob";
		String query3="SELECT * FROM studentmaster where std_dob=(SELECT MIN(std_dob) from studentmaster)";
		String query4="SELECT * FROM studentmaster where std_dob=(SELECT MAX(std_dob) from studentmaster)";
		String query5="SELECT std_name,course_name from   studentmaster JOIN course ON studentmaster.course_id=course.course_id where course_name='commerce'";
		String query6=" SELECT std_name from studentmaster where std_gender='male'";
		String query7="SELECT COUNT(std_gender),std_gender from studentmaster group by std_gender";
		String query8="SELECT std_name,last_name from studentmaster";
		String query9="select std_name from studentmaster where std_name LIKE 'a%'";
		String query10="select * from studentmaster where std_name  like '_n__a%'";
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn=DriverManager.getConnection(url,uname,pass);
		Statement st=conn.createStatement();
		ResultSet rs=st.executeQuery(query);
		System.out.println("1.display all students name in alph order");
		while(rs.next()) {
			System.out.print(rs.getString(2)+",");
			
		}
		System.out.println();
		System.out.println();
		System.out.println("2. List all students id, name, course, gender based on their age.(in ascending order)");
        rs=st.executeQuery(query2);
		while(rs.next()) {
			System.out.println(rs.getInt(1)+","+rs.getString(2)+","+rs.getString(3)+","+rs.getString(4));
			
		}
		
		System.out.println();
		System.out.println();
		System.out.println("3. Display student details of eldest among the all students.");
		rs=st.executeQuery(query3);
		while(rs.next()) {
			System.out.println(rs.getInt(1)+","+rs.getString(2)+","+rs.getString(3)+","+rs.getInt(4)+","+rs.getString(5)+","+rs.getString(6)+","+rs.getString(7)+","+rs.getString(8));
			
		}
		
		
		System.out.println();
		System.out.println();
		System.out.println("4. Display student details of youngest among the all students.");
		rs=st.executeQuery(query4);
		while(rs.next()) {
			System.out.println(rs.getInt(1)+","+rs.getString(2)+","+rs.getString(3)+","+rs.getInt(4)+","+rs.getString(5)+","+rs.getString(6)+","+rs.getString(7)+","+rs.getString(8));
			
		}
		
		System.out.println();
		System.out.println();
		System.out.println("5.List all student names who are all studying commerce.(ie.,Course.COURSE_NAME=\"commerce\").");
		rs=st.executeQuery(query5);
		while(rs.next()) {
			System.out.println(rs.getString(1)+","+rs.getString(2));
			
		}
		
		System.out.println();
		System.out.println();
		System.out.println("6.List all of male students names.");
		rs=st.executeQuery(query6);
		while(rs.next()) {
			System.out.println(rs.getString(1));
			
		}
		
		
		
		System.out.println();
		System.out.println();
		System.out.println("7. View no of male and female students count.");
		rs=st.executeQuery(query7);
		while(rs.next()) {
			System.out.println(rs.getInt(1)+","+rs.getString(2));
			
		}
		
		System.out.println();
		System.out.println();
		System.out.println("8.Display student name lastName as a single string.");
		rs=st.executeQuery(query8);
		while(rs.next()) {
			System.out.println(rs.getString(1)+","+rs.getString(2));
			
		}
		
		System.out.println();
		System.out.println();
		System.out.println("9. Display student names whose name is started with 'N/n'.");
		rs=st.executeQuery(query9);
		while(rs.next()) {
			System.out.println(rs.getString(1));
			
		}
		
		
		System.out.println();
		System.out.println();
		System.out.println("10. Display student names whose name fifth character is 'N/n' and second 'A/a'.");
		rs=st.executeQuery(query10);
		while(rs.next()) {
			System.out.println(rs.getString(2));
			
		}
		
		
	}

}
