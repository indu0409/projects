package com.first;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
  

@Controller
public class HelloController {
@RequestMapping("/hello")

	public ModelAndView execute(HttpServletRequest req, HttpServletResponse res)
	{
	   String uname=req.getParameter("username").toString();
	   ModelAndView mv=new ModelAndView();
       mv.addObject("user", uname);
       mv.setViewName("viewpage");
			   
		return mv;
	}
}

