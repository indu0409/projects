package exercise;

import java.util.Scanner;

public class p2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Scanner sc=new Scanner(System.in);
     int n=sc.nextInt();
     int k=9;
     for(int i=n;i>0;i--)
     {
    	 for(int j=0;j<i;j++)
    	 {
    		 System.out.print(k+" ");
    	 }
    	 k-=2;
    	 System.out.println();
     }
	}

}
