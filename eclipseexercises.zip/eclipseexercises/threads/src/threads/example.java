package threads;


class message extends Thread{
	public void run()
	
	{
		for(int i=1;i<=5;i++)
		{
			System.out.println("inside display method");
			try {
				Thread.sleep(8000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}
}
}
class  prepare extends Thread{
	public void run()
	{
		
		{
			for(int i=0;i<5;i++)
				System.out.println(i);
		}
	}
}
		

	
public class example {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		message msg=new message();
		prepare pr=new prepare();
		msg.start();
		pr.start();
		System.out.println(msg.isAlive());
		System.out.println(pr.isAlive());
		try {
			msg.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			pr.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("bye");
		
	}

}
