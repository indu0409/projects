package threads;
class imp implements Runnable{
	Thread t;
	imp(String name)
	{
		t=new Thread(this,name);
		t.start();
	}
	synchronized public void run()
	{
		for(int i=0;i<=3;i++)
		{
			System.out.println("thread is executing "+t.getName());
			
		}
	}
}
 class multith {
public static void main(String args[])
{
      new imp("thread1");
      new imp("thread2");
      new imp("thread3");
      
      
      
}

}

