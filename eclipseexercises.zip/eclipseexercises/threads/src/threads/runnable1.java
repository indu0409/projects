package threads;
 class message1 implements Runnable{
	
	public void  run()
	{
		for(int i=0;i<=3;i++)
		{
			System.out.println("inside display method");
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
 class prepare1{
	  void execute()
	 {
		 for(int i=0;i<=3;i++)
		 {
			 System.out.println(i);
		 }
	 }
 }

public class runnable1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
message1 msg=new message1();
prepare1 pr=new prepare1();
Thread t=new Thread(msg);
t.start();
pr.execute();
	}

}
