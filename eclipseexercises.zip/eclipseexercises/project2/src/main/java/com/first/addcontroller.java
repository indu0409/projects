package com.first;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class addcontroller {
@RequestMapping("/add")
 public String display()
 {
	return "display.jsp";
 }


}
