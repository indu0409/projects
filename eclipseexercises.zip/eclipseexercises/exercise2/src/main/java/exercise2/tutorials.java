package exercise2;

public class tutorials {
public String execute()
{
	System.out.println("hello world");
	return "";
}
}
