package com.pro;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller
public class addController {
@RequestMapping("/add")
public String addd()
{
	System.out.println("in controller");
	return "display";
}
}
