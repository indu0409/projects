package demo;

import com.opensymphony.xwork2.Action;

public class hello implements Action{
 public String execute()
 {
	 return "success";
 }
}
