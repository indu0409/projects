package com.first.dao;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;


import com.first.bean.*;

public class studentdao {


public int save(student s)throws Exception{    
	String url="jdbc:mysql://localhost:3306/d1",uname="root",pass="";
	String query="INSERT INTO student VALUES(?,?,?)";
	Class.forName("com.mysql.jdbc.Driver");
	Connection conn=DriverManager.getConnection(url,uname,pass);
	PreparedStatement st=conn.prepareStatement(query);
	st.setInt(1,s.getRoll());
	st.setString(2,s.getName());
	st.setString(3, s.getCourse());
	return st.executeUpdate();

	
}    
 
}
