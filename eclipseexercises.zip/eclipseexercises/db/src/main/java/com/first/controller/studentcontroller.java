package com.first.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.ui.Model;  
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.first.bean.student;
import com.first.dao.studentdao;
@Controller
public class studentcontroller {
@RequestMapping("/register")
public String register(HttpServletRequest req,HttpServletResponse res) throws Exception
{
	studentdao dao=new studentdao();
    int rollno=Integer.parseInt(req.getParameter("rollno"));
	String name=req.getParameter("name");
	String course=req.getParameter("course");
	student s=new student();
	s.setRoll(rollno);
	s.setName(name);
	s.setCourse(course);
	if(dao.save(s)>0)
	{
		return "viewpage";
	}
	else
	{
		return "error";
	}
	
}
	
}
