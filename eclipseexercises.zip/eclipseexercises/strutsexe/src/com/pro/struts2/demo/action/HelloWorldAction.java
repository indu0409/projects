package com.pro.struts2.demo.action;

import com.opensymphony.xwork2.ActionSupport;

public class HelloWorldAction extends ActionSupport {
	public String execute() throws Exception {

		return SUCCESS;
	}

}
