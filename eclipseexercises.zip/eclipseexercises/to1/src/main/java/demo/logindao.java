package demo;
import java.sql.*;
public class logindao {
	public boolean validate(String var1,String var2) throws Exception {
String url="jdbc:mysql://localhost:3306/d1",uname="root",pass="";
String query="SELECT * FROM t1 WHERE username=? and password=?";
Class.forName("com.mysql.jdbc.Driver");
Connection conn=DriverManager.getConnection(url,uname,pass);
PreparedStatement st=conn.prepareStatement(query);
st.setString(1,var1);
st.setString(2,var2);
ResultSet rs=st.executeQuery();
return rs.next();
}
	
	public int register(registerbean r)throws Exception{
		String var1=r.getUsername();
		String var2=r.getPassword();
		String url="jdbc:mysql://localhost:3306/d1",uname="root",pass="";
		String query="INSERT INTO t1 VALUES(?,?)";
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn=DriverManager.getConnection(url,uname,pass);
		PreparedStatement st=conn.prepareStatement(query);
		st.setString(1,var1);
		st.setString(2,var2);
		return st.executeUpdate();

	}
}
