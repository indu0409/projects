package com.abc.page;

public class addconctroller {
public String execute()
{
	return "success";
}
}
