package com.spring.jdbc;

import org.springframework.jdbc.core.JdbcTemplate;

public class studentdao {
	private JdbcTemplate template;
public JdbcTemplate getTemplate() {
		return template;
	}
	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}
public int insert(data d)
{
	String query = "INSERT INTO s1 VALUES(?,?,?) ";
	int result=this.template.update(query,d.getRollno(),d.getName(),d.getCourse());
	return result;
	
}
}
