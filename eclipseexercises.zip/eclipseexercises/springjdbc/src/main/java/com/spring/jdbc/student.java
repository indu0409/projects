package com.spring.jdbc;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import com.spring.jdbc.*;
@Controller
public class student {
@RequestMapping("/reg")
public String execute(@Valid HttpServletRequest req,HttpServletResponse res) {
	
	ApplicationContext context=new ClassPathXmlApplicationContext("aaa-servlet.xml");
//JdbcTemplate template=context.getBean("jdbctemplate",JdbcTemplate.class);
//String query = "INSERT INTO s1 VALUES(?,?,?) ";
//int result=template.update(query,5,"lim","cse");
studentdao st=context.getBean("dao",studentdao.class);
	data d=new data();
	d.setRollno(Integer.parseInt(req.getParameter("rollno")));
	d.setName(req.getParameter("name"));
	d.setCourse(req.getParameter("course"));
	int count=st.insert(d);
    return "viewpage";
	}
}

